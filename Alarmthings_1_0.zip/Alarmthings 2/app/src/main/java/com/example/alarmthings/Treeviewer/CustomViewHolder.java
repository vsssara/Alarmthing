package com.example.alarmthings.Treeviewer;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.alarmthings.R;

public class CustomViewHolder extends TreeViewHolder {

    private TextView fileName;
    private ImageView fileStateIcon;
    private ImageView fileTypeIcon;


    public CustomViewHolder(@NonNull View itemView) {
        super(itemView);

        fileName = itemView.findViewById(R.id.file_name);
        fileStateIcon = itemView.findViewById(R.id.file_state_icon);
        fileTypeIcon = itemView.findViewById(R.id.file_type_icon);
    }
    private void initViews() {

    }

    @Override
    public void bindTreeNode(TreeNode node) {
        super.bindTreeNode(node);
        // Here you can bind your node and check if it selected or not

        String fileNameStr = node.getValue().toString();
        fileName.setText(fileNameStr);


    }
}
