package com.example.alarmthings.Animate;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.alarmthings.R;
import com.lorentzos.flingswipe.SwipeFlingAdapterView;

import java.util.ArrayList;

public class AnimatActivity extends AppCompatActivity {

    ImageView imageView  , people , connect,chat;
    Button dislike ,like  ;

    private SwipeFlingAdapterView flingContainer;
    private int i;

    ArrayList al = new ArrayList<String>();
    ArrayList img_url = new ArrayList<String>();
    ArrayList user_name = new ArrayList<String>();
    ArrayList backup_img_url = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animat);

        imageView= findViewById(R.id.imageview);

        people= findViewById(R.id.people);
        connect= findViewById(R.id.connect);
        chat= findViewById(R.id.chat);

        dislike  = findViewById(R.id.dislike);
        like  = findViewById(R.id.like);

        flingContainer = (SwipeFlingAdapterView) findViewById(R.id.swipe_list);



        call_api_( false );

        final MyAdapter dd = new MyAdapter( this , img_url , al , al ) ;

        //set the listener and the adapter
        flingContainer.setAdapter( dd );
        dd.notifyDataSetChanged();

        flingContainer.setFlingListener(new SwipeFlingAdapterView.onFlingListener() {
            @Override
            public void removeFirstObjectInAdapter() {
                // this is the simplest way to delete an object from the Adapter (/AdapterView)
                Log.d("LIST", "removed object!");
                al.remove(0);
                img_url.remove(0);
                dd.notifyDataSetChanged();
            }

            @Override
            public void onLeftCardExit(Object dataObject) {
                //Do something on the left!
                //You also have access to the original object.
                //If you want to use it just cast it (String) dataObject
//                Toast.makeText(AnimatActivity.this, "Left!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onRightCardExit(Object dataObject) {
//                Toast.makeText(AnimatActivity.this, "Right!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAdapterAboutToEmpty(int itemsInAdapter) {
                // Ask for more data here
                try {
                    if (itemsInAdapter==1){
                        al.add( user_name.get(i) );
                        img_url.add(backup_img_url.get(i));
                        dd.notifyDataSetChanged();
                        Log.d("LIST..." + i, "notified..."+itemsInAdapter);
                         i++;
                        if (i == 7){
                           i=0;
                        }
                    }
                }
                catch (Exception err){
                    Toast.makeText(AnimatActivity.this, "error comes", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onScroll(float v) {

            }
        });


        // Optionally add an OnItemClickListener
        flingContainer.setOnItemClickListener(new SwipeFlingAdapterView.OnItemClickListener() {
            @Override
            public void onItemClicked(int itemPosition, Object dataObject) {
//                makeToast(MyActivity.this, "Clicked!");
                Toast.makeText(AnimatActivity.this, "Clicked", Toast.LENGTH_SHORT).show();
            }

        });


        like.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.ani_left_right);
//                imageView.startAnimation(animation);
//
//                System.out.println(".......... anima...........");
//                Toast.makeText(AnimatActivity.this, ".......anim......", Toast.LENGTH_SHORT).show();
//
//                timer();

                flingContainer.getTopCardListener().selectLeft();

            }
        });


        dislike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.ani_right_left);
//                imageView.startAnimation(animation);
//
//                System.out.println(".......... anima...........");
//                Toast.makeText(AnimatActivity.this, ".......anim......", Toast.LENGTH_SHORT).show();
//
//                timer();

                flingContainer.getTopCardListener().selectRight();
            }
        });


        people.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }

    private void call_api_( boolean work ) {

        al.add("agent 1");
        al.add("agent 2");
        al.add("agent 3");
        al.add("agent 4");

        img_url.add("https://cdn.pixabay.com/photo/2015/12/01/20/28/road-1072823__340.jpg");
        img_url.add("https://image.shutterstock.com/image-photo/mountains-during-sunset-beautiful-natural-260nw-407021107.jpg");
        img_url.add("https://thumbs.dreamstime.com/b/environment-earth-day-hands-trees-growing-seedlings-bokeh-green-background-female-hand-holding-tree-nature-field-gra-130247647.jpg");
        img_url.add("https://thumbs.dreamstime.com/b/beautiful-rain-forest-ang-ka-nature-trail-doi-inthanon-national-park-thailand-36703721.jpg");



        user_name.add("agent 5");
        user_name.add("agent 6");
        user_name.add("agent 7");
        user_name.add("agent 8");
        user_name.add("agent 9");
        user_name.add("agent 12");
        user_name.add("agent 13");
        user_name.add("agent 14");

        backup_img_url.add("https://images.pexels.com/photos/39857/leopard-leopard-spots-animal-wild-39857.jpeg?cs=srgb&dl=pexels-pixabay-39857.jpg&fm=jpg");
        backup_img_url.add("https://images.pexels.com/photos/34098/south-africa-hluhluwe-giraffes-pattern.jpg?cs=srgb&dl=pexels-pixabay-34098.jpg&fm=jpg");
        backup_img_url.add("https://ichef.bbci.co.uk/news/976/cpsprodpb/CB4E/production/_93264025_tigers.jpg");
        backup_img_url.add("https://learnenglish.britishcouncil.org/sites/podcasts/files/RS6053_dv029034-low.jpg");

        backup_img_url.add("https://bd.gaadicdn.com/processedimages/hero-motocorp/hero-motocorp-splendor/640X309/hero-motocorp-splendor628c6c03932f2.jpg");
        backup_img_url.add("https://imgd.aeplcdn.com/370x208/n/cw/ec/124863/ninja-400-right-front-three-quarter.gif?isig=0&q=75");
        backup_img_url.add("https://economictimes.indiatimes.com/thumb/msid-75572296,width-640,resizemode-4,imgsize-507941/bmw-ninet.jpg");
        backup_img_url.add("https://images.news18.com/ibnlive/uploads/2022/06/tesla-cybertruck-bike-16554583054x3.jpg");


        if ( work )
        {
        final MyAdapter dd = new MyAdapter( this , img_url , al , al ) ;

        //set the listener and the adapter
        flingContainer.setAdapter( dd );
        dd.notifyDataSetChanged();
        }
    }


    public void timer()
    {

        new Handler().postDelayed(new  Runnable() {
        public void run() {
            // call JSON methods here
            // To add zoom animation
            System.out.println(".......... anima2222...........");
            Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.ani2);
            imageView.startAnimation(animation);

//            cal_anim2();
        }
       }, 800  );



    }


}