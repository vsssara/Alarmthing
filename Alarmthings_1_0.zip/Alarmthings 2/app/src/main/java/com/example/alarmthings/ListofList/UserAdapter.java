package com.example.alarmthings.ListofList;

import static com.example.alarmthings.ListofList.ListListActivity.User_userid;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.alarmthings.R;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder> {

    private List<User> userList;

    String update_data="";

    public UserAdapter(List<User> userList) {
        this.userList = userList;
    }

    public UserAdapter()
    {
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user, parent, false);
        return new ViewHolder(view);
    }

    public void updateData( String data) {
        update_data = data ;
        notifyDataSetChanged();
    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        User user = userList.get(position);
        holder.txtName.setText(user.getPath());
        holder.recyclerView.setLayoutManager(new LinearLayoutManager(holder.itemView.getContext()));
        holder.recyclerView.setAdapter(new UserAdapter(user.getChildren()));

        if(user.getChildren().size()>0){
            holder.droplist_img.setVisibility(View.VISIBLE);
        }
        holder.droplist_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (holder.recyclerView.getVisibility() == View.VISIBLE){
                    holder.recyclerView.setVisibility(View.GONE);
                }
                else {
                    holder.recyclerView.setVisibility(View.VISIBLE);
                }
            }
        });

        holder.recyclerView.setVisibility(View.GONE);

        holder.txtName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(v.getContext(), user.getPath()+"id.."+User_userid.get(user.getPath()) , Toast.LENGTH_SHORT).show();

            }
        });

        if (!update_data.equals("")){
            holder.recyclerView.setVisibility(View.VISIBLE);
        }

    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtName;
        RecyclerView recyclerView;
        ImageView droplist_img;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtName = itemView.findViewById(R.id.txtName);
            recyclerView = itemView.findViewById(R.id.subRecyclerView);
            droplist_img = itemView.findViewById(R.id.droplist_img);
        }
    }
}

