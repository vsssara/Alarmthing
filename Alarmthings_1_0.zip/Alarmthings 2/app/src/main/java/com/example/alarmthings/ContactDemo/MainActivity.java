package com.example.alarmthings.ContactDemo;


import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.alarmthings.R;
//import com.google.android.gms.ads.MobileAds;
//import com.google.android.gms.ads.initialization.InitializationStatus;
//import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.mikhaellopez.circularimageview.CircularImageView;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    CircularImageView profile_img;
    ImageView dot;

    //for image upload
    private static final int SELECT_PICTURE = 100;
    private Uri selectedImageUri;
    //ImageView profile_img;
    public Bitmap bp;
    public byte[] photo;

    private static final String TAG = "StoreImageActivity";


    DatabaseHelper myDb;
    EditText editName, editSurname, editMarks, editTextId;
    Button btnAddData, update;
    Button btnviewAll, btn_viewone;
    Button btnDelete, deleteone;

    String id , id_str= "", name_str, pass_str, phone_str, user_name_by_id, name, phone, pass;

    Button btnviewUpdate;

    Spinner spinner;
    Locale myLocale;
    String currentLanguage = "en", currentLang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);


        // Initialize the Mobile Ads SDK
//        MobileAds.initialize(this, new OnInitializationCompleteListener() {
//            @Override
//            public void onInitializationComplete(InitializationStatus initializationStatus) {
////                Toast.makeText(MainActivity.this, "ADS sucesfull ", Toast.LENGTH_SHORT).show();
//            }
//        });

//        AdView mAdView;
//        mAdView = findViewById(R.id.adView);
//        AdRequest adRequest = new AdRequest.Builder().build();
//        mAdView.loadAd(adRequest);



//--------------image change language------------
        dot= (ImageView) findViewById(R.id.dot);

        dot.setRotation(dot.getRotation() + 90);

        dot.setOnClickListener(new View.OnClickListener() {
                                                 @Override
                                                 public void onClick(View v)
                                                 {

                                                     spinner.setVisibility(View.VISIBLE);
                                                 }
                                             });

        currentLanguage = getIntent().getStringExtra(currentLang);

        spinner = (Spinner)findViewById(R.id.spin);

        List<String> list = new ArrayList<String>();

        list.add("Select language");
        list.add("English");
        list.add("Tamil");
        list.add("Hindi");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                switch (position) {
                    case 0:
                        break;
                    case 1:
                        setLocale("en");
                        break;
                    case 2:
                        setLocale("tl");
                        break;
                    case 3:
                        setLocale("hi");
                        break;

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
//--------------------------------------------------
        myDb = new DatabaseHelper(this);

        profile_img = (CircularImageView) findViewById(R.id.profile_img);
        // loaded_img=(ImageView)findViewById(R.id.loaded_img) ;

        editName = (EditText) findViewById(R.id.editText_name);
        editSurname = (EditText) findViewById(R.id.editText_surname);
        editMarks = (EditText) findViewById(R.id.editText_Marks);
        //  editTextId = (EditText)findViewById(R.id.editText_id);
        btnAddData = (Button) findViewById(R.id.button_add);
        btnviewAll = (Button) findViewById(R.id.button_viewAll);
//        btnviewUpdate= (Button)findViewById(R.id.button_update);
        btnDelete = (Button) findViewById(R.id.button_delete);
//        btn_viewone= (Button)findViewById(R.id.button_viewone);
//        deleteone= (Button)findViewById(R.id.button_deleteone);

        //------------------update a item list---------------------------------
        update = (Button) findViewById(R.id.btn_edit);
        update.setVisibility(View.INVISIBLE);
        update();

        Intent intent = getIntent();
        id_str = intent.getStringExtra("id");


        if (id_str != null ) {

            name_str = intent.getStringExtra("name");
            pass_str = intent.getStringExtra("password");
            phone_str = intent.getStringExtra("phone");

            editName.setText(name_str);
            editSurname.setText(pass_str);
            editMarks.setText(phone_str);

            btnAddData.setVisibility(View.INVISIBLE);
            btnviewAll .setVisibility(View.INVISIBLE);
            btnDelete .setVisibility(View.INVISIBLE);

            update .setVisibility(View.VISIBLE);
        }
      //-------------------------------------------------
        AddData();
        viewAll();
//        UpdateData();
        DeleteData();
//        Delete_by_username();
//        viewOne();

        img_uplaod();

    }


    public void setLocale(String localeName) {
        if (!localeName.equals(currentLanguage)) {
            myLocale = new Locale(localeName);
            Resources res = getResources();
            DisplayMetrics dm = res.getDisplayMetrics();
            Configuration conf = res.getConfiguration();
            conf.locale = myLocale;
            res.updateConfiguration(conf, dm);
            Intent refresh = new Intent(this, MainActivity.class);
            refresh.putExtra(currentLang, localeName);
            startActivity(refresh);
            // text.setText(localeName);

        } else {
            Toast.makeText(MainActivity.this, "Language already selected!", Toast.LENGTH_SHORT).show();
        }
    }

    public void onBackPressed() {
        startActivity(new Intent(this,DetailsActivity.class));
        finish();
       // System.exit(0);
    }

    public void update() {
        update.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        //startActivity(new Intent(MainActivity.this, DashActivity.class));
                        if(bp!=null)
                        {
                            photo = profileImage(bp);
                        }
                        boolean check = myDb.updateData(id_str, editName.getText().toString(), editSurname.getText().toString(), editMarks.getText().toString(),photo);
                        {
                            if (check == true) {

                                Toast.makeText(MainActivity.this, "Data is update", Toast.LENGTH_LONG).show();
                                finish();
                                startActivity(new Intent(MainActivity.this,DetailsActivity.class));

                            } else {
                                Toast.makeText(MainActivity.this, "Data not update", Toast.LENGTH_LONG).show();
                            }


                        }
                    }
                }
        );
    }

    public void img_uplaod() {
        profile_img.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        openImageChooser();
                    }
                }
        );

    }

    // Choose an image from Gallery
    void openImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), SELECT_PICTURE);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            Uri choosenImage = data.getData();
            if (requestCode == SELECT_PICTURE) {
                selectedImageUri = data.getData();
                if (null != selectedImageUri) {

                    //  profile_img.setImageURI(selectedImageUri);

                    bp = decodeUri(choosenImage, 400);

                    profile_img.setImageBitmap(bp);
                }
            }
        }
    }

    public Bitmap decodeUri(Uri selectedImage, int REQUIRED_SIZE) {

        try {

            // Decode image size
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(getContentResolver().openInputStream(selectedImage), null, o);

            // The new size we want to scale to
            // final int REQUIRED_SIZE =  size;

            // Find the correct scale value. It should be the power of 2.
            int width_tmp = o.outWidth, height_tmp = o.outHeight;
            int scale = 1;
            while (true) {
                if (width_tmp / 2 < REQUIRED_SIZE
                        || height_tmp / 2 < REQUIRED_SIZE) {
                    break;
                }
                width_tmp /= 2;
                height_tmp /= 2;
                scale *= 2;
            }

            // Decode with inSampleSize
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = scale;
            return BitmapFactory.decodeStream(getContentResolver().openInputStream(selectedImage), null, o2);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    //Convert bitmap to bytes
    public byte[] profileImage(Bitmap b) {

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.PNG, 0, bos);
        return bos.toByteArray();

    }


    public void viewAll() {
        btnviewAll.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor res = myDb.getAllData();
                        if (res.getCount() == 0) {
                            // show message
                            showMessage("Error", "Nothing found");
                            return;
                        }

                        StringBuffer buffer = new StringBuffer();
                        while (res.moveToNext()) {
                            buffer.append("Id :" + res.getString(0) + "\n");
                            buffer.append("Name :" + res.getString(1) + "\n");
                            buffer.append("PHONE :" + res.getString(2) + "\n");
                            buffer.append("PASSWORD :" + res.getString(3) + "\n\n");
                        }

                        // Show all data
                        showMessage("Data", buffer.toString());

                        finish();
                        startActivity(new Intent(MainActivity.this, DetailsActivity.class));
                    }
                }
        );
    }


    public void AddData() {
        btnAddData.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        validate();
                    }
                }
        );
    }

    public static Bitmap getImage(byte[] image) {
        return BitmapFactory.decodeByteArray(image, 0, image.length);
    }

    private Bitmap imageView2Bitmap(ImageView view){

        Bitmap bitmap = ((BitmapDrawable) view.getDrawable()).getBitmap();
        return bitmap;
    }

    private boolean validate() {

        String MobilePattern = "[0-9]{10}";
        //String email1 = email.getText().toString().trim();
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        //this is validation of email id
//        if (editName.getText().toString().matches(emailPattern)) {

        if(emailPattern!=null){
            //check editName in database
            boolean check = myDb.check_name(editName.getText().toString());
            {
                if (check == true) {
                    if (bp != null) {
                        photo = profileImage(bp);
                    }
                    else
                    {
                        //profile_img.setImageResource(R.drawable.delete);
                      Bitmap empty_img= imageView2Bitmap(profile_img);
                        photo = profileImage(empty_img);
                    }
                    editSurname.setText(" ");
                    boolean isInserted = myDb.insertData(editName.getText().toString(),
                            editSurname.getText().toString(),
                            editMarks.getText().toString(), photo);

                    if (isInserted == true) {
                        Toast.makeText(MainActivity.this, "Data Inserted", Toast.LENGTH_LONG).show();
                        finish();
                        startActivity(new Intent(MainActivity.this, DetailsActivity.class));
                    }
                    else
                        Toast.makeText(MainActivity.this, "Data not Inserted", Toast.LENGTH_LONG).show();

                } else {
                    Toast.makeText(MainActivity.this, "Data not Inserted,Email id alraedy exist", Toast.LENGTH_LONG).show();
                }


            }


            //Toast.makeText(getApplicationContext(),"valid email address",Toast.LENGTH_SHORT).show();
            //  return true;

        } else if (!editName.getText().toString().matches(emailPattern)) {

            Toast.makeText(getApplicationContext(), "Please Enter Valid Email Address", Toast.LENGTH_SHORT).show();
            return false;

        } else if (editMarks.getText().toString().matches(MobilePattern)) {

            Toast.makeText(getApplicationContext(), "phone number is valid", Toast.LENGTH_SHORT).show();
            return true;

        } else if (!editMarks.getText().toString().matches(MobilePattern)) {

            Toast.makeText(getApplicationContext(), "Please enter valid 10 digit phone number", Toast.LENGTH_SHORT).show();
            return false;
        }
        return false;
    }

    public void DeleteData() {
        btnDelete.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // myDb.delete_all_data();
                        // Integer deletedRows = myDb.deleteData(editTextId.getText().toString());

                        editName.setText("");
                        editSurname.setText("");
                        editMarks.setText("");

                        //myDb.delete_by_username(editName.getText().toString());

//                        if(deletedRows > 0)
//                            Toast.makeText(MainActivity.this,"Data Deleted",Toast.LENGTH_LONG).show();
//                        else
//                           Toast.makeText(MainActivity.this,"Data  Deleted",Toast.LENGTH_LONG).show();
                    }
                }
        );
    }


    //----------------------------------
    //delete all records in table
    //myDb.delete_by_username(editName.getText().toString());
    //--------------------------------


    public void showMessage(String title, String Message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }


}
