package com.example.alarmthings.BatteryLevel;

import static android.content.Context.BATTERY_SERVICE;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.BatteryManager;
import android.speech.tts.TextToSpeech;
import android.util.Log;

import java.util.Locale;

public class myBackgroundProcess extends BroadcastReceiver {


    private TextToSpeech mTTS;

    @Override
    public void onReceive(final Context context, Intent intent) {
        mTTS = new TextToSpeech(context.getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.ERROR) {
                    int result = mTTS.setLanguage(Locale.US);

                    if (result == TextToSpeech.LANG_MISSING_DATA
                            || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Log.e("TTS", "Language not supported");

                    }
                    else {

                        BatteryManager bm = (BatteryManager) context.getSystemService(BATTERY_SERVICE);
                        int batLevel = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
                        if(batLevel==100 || batLevel<=10 || batLevel==50 || batLevel>=80)
                            speak(context,batLevel);
                    }
                } else {
                    Log.e("TTS", "Initialization failed");

                }
            }
        });

    }


    public void speak(Context context, int batlevel)
    {
        mTTS.setPitch(10);
        mTTS.setSpeechRate(1);
        String text=String.valueOf(batlevel);
        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }
}
