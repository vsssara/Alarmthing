package com.example.alarmthings.ListofList;

import java.util.List;

public class User
{
    private String path;
    private List<User> children;

    public User(String path, List<User> children) {
        this.path = path;
        this.children = children;
    }


    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public List<User> getChildren() {
        return children;
    }

    public void setChildren(List<User> children) {
        this.children = children;
    }
}
