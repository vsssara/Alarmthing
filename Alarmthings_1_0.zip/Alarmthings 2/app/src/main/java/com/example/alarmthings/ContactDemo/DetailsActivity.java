package com.example.alarmthings.ContactDemo;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;
import com.example.alarmthings.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;


/**
 * Created by tutlane on 05-01-2018.
 */

public class DetailsActivity extends AppCompatActivity
{
public Context context;
    private static TextView user_name, pass_word, phone_no,id_item;
    int i;
    RelativeLayout DetailActivityXml;
    Button showPopupBtn, closePopupBtn, DeletePopupBtn, editPopupBtn;
    PopupWindow popupWindow;
    Intent intent;
    String Username_str, phone_str, password_str,id_item_str;
    DatabaseHelper myDb;
    ImageView img_profile;
    Bitmap bitmap;
    private final static String TAG = MainActivity.class.getSimpleName();

    ListView mListView;
    ArrayList<Model> mList;
    RecordListAdapter mAdapter = null;

  //  public SwipeLayout swipeLayout;

    //multi languages
    ImageView dot;
    Spinner spinner;
    Locale myLocale;
    String currentLanguage = "en", currentLang;

    SwipeMenuListView lv;

    FloatingActionButton floatingActionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        //--------------image change language------------
            dot= (ImageView) findViewById(R.id.dot);
        spinner = (Spinner)findViewById(R.id.spin);

        dot.setRotation(dot.getRotation() + 90);

        dot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

                spinner.setVisibility(View.VISIBLE);
            }
        });
        currentLanguage = getIntent().getStringExtra(currentLang);

        spinner = (Spinner)findViewById(R.id.spin);

        List<String> list = new ArrayList<String>();

        list.add("Select language");
        list.add("English");
        list.add("Tamil");
        list.add("Hindi");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                switch (position) {
                    case 0:
                        break;
                    case 1:
                        setLocale("en");
                        break;
                    case 2:
                        setLocale("tl");
                        break;
                    case 3:
                        setLocale("hi");
                        break;

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });

        // -----------------------------
        myDb = new DatabaseHelper(this);

        DetailActivityXml = (RelativeLayout) findViewById(R.id.DetailActivityXml);

        DatabaseHelper db = new DatabaseHelper(this);

        ArrayList<HashMap<String, String>> userList = db.GetUsers();

//--------------------------listview using adapter------------------------------------------
        mList = new ArrayList<>();

        //get all data from sqlite
        Cursor cursor = myDb.getAllData();
        //mList.clear();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String name = cursor.getString(1);   //------------using database
            String age = cursor.getString(2);
            String phone = cursor.getString(3);
            byte[] image = cursor.getBlob(4);
            //add to list
            mList.add(new Model(id, name, age, phone, image));
        }

//        ActionBar actionBar = getSupportActionBar();
//        actionBar.setTitle("Record List");

         lv = (SwipeMenuListView) findViewById(R.id.user_list);

        mAdapter = new RecordListAdapter(this, R.layout.list_row, mList);     //------------using Adapter

        lv.setAdapter(mAdapter);
  //------------------------------------------------------------------------------------

        //http://www.anjadev.com/all/programming/android_development/swipe-menu-for-list-view-swipemenulistview/
        //https://github.com/baoyongzhang/SwipeMenuListView

        SwipeMenuCreator creator = new SwipeMenuCreator() {

            @Override
            public void create(SwipeMenu menu) {
                //create an action that will be showed on swiping an item in the list
                SwipeMenuItem item1 = new SwipeMenuItem(
                        getApplicationContext());
                item1.setBackground(new ColorDrawable(Color.DKGRAY));
                // set width of an option (px)
                item1.setWidth(200);
                item1.setTitle("Edit");
                item1.setTitleSize(18);
                item1.setTitleColor(Color.WHITE);
                menu.addMenuItem(item1);

                SwipeMenuItem item2 = new SwipeMenuItem(
                        getApplicationContext());
                // set item background
                item2.setBackground(new ColorDrawable(Color.RED));
                item2.setWidth(200);
                item2.setTitle("Delete");
                item2.setTitleSize(18);
                item2.setTitleColor(Color.WHITE);
                menu.addMenuItem(item2);
            }
        };

        //set MenuCreator
        lv.setMenuCreator(creator);
        // set SwipeListener
        lv.setOnSwipeListener(new SwipeMenuListView.OnSwipeListener() {

            @Override
            public void onSwipeStart(int position) {
                // swipe start
            }

            @Override
            public void onSwipeEnd(int position) {
                // swipe end
            }
        });

        //in this area two button of swipe menu in the Listview case 0 is edit and case 1 is delete
        lv.setOnMenuItemClickListener(new SwipeMenuListView.OnMenuItemClickListener() {

                @Override
            public boolean onMenuItemClick(int position, SwipeMenu menu, int index) {
                  //mAdapter.getItem(position);
                    String value = mAdapter.getItem(position).toString();
                switch (index)
                {
                    case 0:
                        Toast.makeText(getApplicationContext(), "Action 1 for " , Toast.LENGTH_SHORT).show();

                        i = lv.getAdapter().getCount();
                        // for (int i = 0; i < adapter.getCount(); i++)

                        //this loop is used to find a position of selected item in the list
                        for (int j = 0; j < i; j++) {
                            //j is position value of listview
                            if (position == j)
                            {
                                int z = j;
                                {
                                    View view;
                                    view = null;
                                    view = mAdapter.getView(z, view, lv);


                                    user_name = (TextView) view.findViewById(R.id.UserName);
                                    Username_str = user_name.getText().toString();

                                    Toast.makeText(getApplicationContext(), Username_str,
                                            Toast.LENGTH_SHORT).show();

                                    //----------popup file-----------------

                                   // finish();
                                    call_popup();

                                    //--------------------------------------
                                }
                            }
                        }
                        break;
                    case 1:
                        Toast.makeText(getApplicationContext(), "Action 2 for "+ value  , Toast.LENGTH_SHORT).show();

                        i = lv.getAdapter().getCount();
                        // for (int i = 0; i < adapter.getCount(); i++)

                        //this loop is used to find a position of selected item in the list
                        for (int j = 0; j < i; j++) {
                            //j is position value of listview
                            if (position == j)
                            {
                                int z = j;
                                {
                                    View view;
                                    view = null;
                                    view = mAdapter.getView(z, view, lv);
                                    user_name = (TextView) view.findViewById(R.id.UserName);
                                    Username_str = user_name.getText().toString();

                                    Toast.makeText(getApplicationContext(), Username_str,
                                            Toast.LENGTH_SHORT).show();

                                    //----------delete-----------------

                                    Cursor res = myDb.del_by_name(Username_str);

                                    StringBuffer buffer = new StringBuffer();
                                    while (res.moveToNext()) {
                                        buffer.append(res.getString(0) + "\n");
                                    }

                                    // showMessage("Data", buffer.toString());

                                    String user_name_by_id = buffer.toString();

                                    Integer deletedRows = myDb.delete_by_username(user_name_by_id);

                                    if (deletedRows > 0)
                                        Toast.makeText(DetailsActivity.this, "Data Deleted", Toast.LENGTH_LONG).show();
                                    else
                                        Toast.makeText(DetailsActivity.this, "Data not Deleted", Toast.LENGTH_LONG).show();

                                    startActivity(new Intent(DetailsActivity.this, DetailsActivity.class));
                                    finish();
                                    //--------------------------------------
                                }
                            }
                        }
                        break;
                }
                return false;
            }});

        // this is only for click a particular item in list view find the position of item and show popup of that item
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                //int i is used for count no of list in Adapter for looping to find a position in list
                i = lv.getAdapter().getCount();
                    // for (int i = 0; i < adapter.getCount(); i++)

              //this loop is used to find a position of selected item in the list
                for (int j = 0; j < i; j++) {
                      //j is position value of listview
                    if (position == j) {
                        view = null;

                        int z = j;
                        {
                            view = mAdapter.getView(z, view, lv);

//                            pass_word = (TextView) findViewById(R.id.Phone_no);
//                            pass_word.setVisibility(View.GONE);
                            img_profile=(ImageView)view.findViewById(R.id.image);
                            user_name = (TextView) view.findViewById(R.id.UserName);
                            phone_no = (TextView) view.findViewById(R.id.pass);
                            pass_word = (TextView) view.findViewById(R.id.Phone_no);
                            id_item = (TextView) view.findViewById(R.id.id_item);


                            Username_str = user_name.getText().toString();
                            phone_str = phone_no.getText().toString();
                            password_str = pass_word.getText().toString();
                            id_item_str = id_item.getText().toString();

                            Toast.makeText(getApplicationContext(), Username_str,
                                    Toast.LENGTH_SHORT).show();

                           // finish();
                            call_popup();

                        }

                    }
                }


            }
        });


        Button back = (Button) findViewById(R.id.btnBack);
        back.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                intent = new Intent(DetailsActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        //----------------floatingActionButton-------------------
        floatingActionButton=(FloatingActionButton)findViewById(R.id.floatingActionButton);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                startActivity(new Intent(DetailsActivity.this,MainActivity.class));
            finish();
            }
        });

    }

    private Bitmap imageView2Bitmap(ImageView view){

            Bitmap bitmap = ((BitmapDrawable) view.getDrawable()).getBitmap();
            return bitmap;
    }

    public void call_popup()
    {
        //instantiate the popup.xml layout file
        LayoutInflater  layoutInflater = (LayoutInflater) DetailsActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View customView1 = layoutInflater.inflate(R.layout.popup, null);
        //  popupWindow = new PopupWindow(customView1, 810, 850, true);

        //instantiate popup window
        popupWindow = new PopupWindow(customView1, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);

        //display the popup window
        popupWindow.showAtLocation(DetailActivityXml, Gravity.CENTER, 0, 0);
        // If you need the PopupWindow to dismiss when when touched outside
        popupWindow.setBackgroundDrawable(new ColorDrawable());


        //for disable by click out side
        popupWindow.setOutsideTouchable(true);
        popupWindow.setTouchable(true);
        popupWindow.setFocusable(true);
        // If you need the PopupWindow to dismiss when when touched outside
        popupWindow.setBackgroundDrawable(new ColorDrawable());

//https://inducesmile.com/android-programming/how-to-get-bitmap-from-imageview-in-android/

        ImageView img_at_1=(ImageView)customView1.findViewById(R.id.image_at_1);

        if (img_profile!=null)
        {
            img_at_1.setImageBitmap(imageView2Bitmap(img_profile));
        }

        // initialize a textview of popup xml
       final TextView popup_username = (TextView) customView1.findViewById(R.id.popup_txt_username);
        final TextView popup_phone = (TextView) customView1.findViewById(R.id.popup_phone);
        final TextView popup_password = (TextView) customView1.findViewById(R.id.popup_password);
        final TextView popup_id_item = (TextView) customView1.findViewById(R.id.popup_id_item);

        popup_username.setText(Username_str);
        popup_phone.setText(password_str);
        popup_password.setText(phone_str);
        popup_id_item.setText(id_item_str);

        closePopupBtn = (Button) customView1.findViewById(R.id.closePopupBtn);

        closePopupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
            }
        });

        editPopupBtn = (Button) customView1.findViewById(R.id.edit_PopupBtn);

        editPopupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
               // popup_username.VISIBLE
              //  popup_username.setVisibility(View.INVISIBLE);

                Intent i = new Intent(DetailsActivity.this, MainActivity.class);
                i.putExtra("id", id_item_str);
                i.putExtra("name", Username_str);
                i.putExtra("phone", password_str);
                i.putExtra("password", phone_str);
                startActivity(i);
                finish();

            }
        });


        DeletePopupBtn = (Button) customView1.findViewById(R.id.delete_PopupBtn);

        DeletePopupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor res = myDb.del_by_name(Username_str);
                if (res.getCount() == 0) {
                    // show message
                    showMessage("Error", "Nothing found");
                    return;
                }


                StringBuffer buffer = new StringBuffer();
                while (res.moveToNext()) {
                    buffer.append(res.getString(0) + "\n");
                }

                // showMessage("Data", buffer.toString());

                String user_name_by_id = buffer.toString();

                Integer deletedRows = myDb.delete_by_username(user_name_by_id);

                if (deletedRows > 0)
                    Toast.makeText(DetailsActivity.this, "Data Deleted", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(DetailsActivity.this, "Data not Deleted", Toast.LENGTH_LONG).show();

                popupWindow.dismiss();

                startActivity(new Intent(DetailsActivity.this, DetailsActivity.class));
            }
        });

    }

    public void showMessage(String title, String Message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }

    public void setLocale(String localeName) {
        if (!localeName.equals(currentLanguage)) {
            myLocale = new Locale(localeName);
            Resources res = getResources();
            DisplayMetrics dm = res.getDisplayMetrics();
            Configuration conf = res.getConfiguration();
            conf.locale = myLocale;
            res.updateConfiguration(conf, dm);
            Intent refresh = new Intent(this, DetailsActivity.class);
            refresh.putExtra(currentLang, localeName);
            startActivity(refresh);
            // text.setText(localeName);

        } else {
            Toast.makeText(DetailsActivity.this, "Language already selected!", Toast.LENGTH_SHORT).show();
        }
    }

}