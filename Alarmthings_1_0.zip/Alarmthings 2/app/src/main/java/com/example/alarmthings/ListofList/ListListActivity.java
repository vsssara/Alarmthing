package com.example.alarmthings.ListofList;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.alarmthings.R;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;

public class ListListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;

    static HashMap<String, String> User_userid = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_list);

        int ALL_PERMISSIONS = 101;
        final String[] permissions = new String[]{
                Manifest.permission.READ_MEDIA_IMAGES
                ,Manifest.permission.READ_EXTERNAL_STORAGE ,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        } ;
        ActivityCompat.requestPermissions(this, permissions, ALL_PERMISSIONS);



        if (ContextCompat.checkSelfPermission(ListListActivity.this,
                Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED)
        {


        }
        else {
            Toast.makeText(this, "no permission granded", Toast.LENGTH_SHORT).show();
        }

        // Initiate_json_creator();

//        String json = "\n" +
//                "{\"path\":\"\",\"children\":[{\"path\":\"mnt\",\"children\":[{\"path\":\"sdcard\",\"children\":[{\"path\":\"folder1\",\"children\":[{\"path\":\"a\",\"children\":[{\"path\":\"b\",\"children\":[{\"path\":\"file1.file\",\"children\":[]},{\"path\":\"file2.file\",\"children\":[]}]}]}]}]}]},{\"path\":\"D\",\"children\":[{\"path\":\"a\",\"children\":[{\"path\":\"b\",\"children\":[{\"path\":\"c.file\",\"children\":[]}]}]}]}]}";

        String json = Initiate_json_creator();

        Gson gson = new Gson();

        User yourclass = gson.fromJson(json, User.class);



//        yourclass.getChildren().get(0).getChildren().get(0);

//        System.out.println("data..."+ yourclass.getChildren().get(0).getChildren().get(0).getPath() );


        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<User> userList = yourclass.getChildren();

        recyclerView.setAdapter(new UserAdapter(userList));
                //generateUserList(); // Assume you have some method to generate user list


    }

    private String Filter_json_creator( String filterdata) {

        ArrayList<String> newdata =  filter(filterdata);

        MenuTree t = new MenuTree();
        for (String s : newdata) {
            t.add(s);
        }

        System.out.println(t.toJSON().toString());

        return t.toJSON().toString() ;

    }


    private String Initiate_json_creator() {
        String slist[] = new String[]{
                "mnt/sdcard/folder1/a/b/file1.file",
                "mnt/sdcard/folder1/a/b/file2.file",
                "D/a/b/c.file",

        };


        ArrayList<String> newdata =  apidata();

//                new ArrayList<>();
//        newdata.add("mnt/sdcard/folder1/a/b/file1.file");
//        newdata.add("mnt/sdcard/folder1/a/b/file2.file");
//        newdata.add("mnt/sdcard/folder1/a/b/file3.file");
//        newdata.add("D/a/b/c.file");
//        newdata.add("D/a/b/c.file2");
//        newdata.add("D/a/b/c.file3");
//        newdata.add("D/a/b/c.file4");
//        newdata.add("mnt/sdcard/folder2/a/b/file1.file");
//        newdata.add("mnt/sdcard/folder2/a/b/file2.file");



        MenuTree t = new MenuTree();
        for (String s : newdata) {
            t.add(s);
        }

        System.out.println(t.toJSON().toString());

        return t.toJSON().toString() ;
    }


    // Method to generate dummy user list
    private List<User> generateUserList() {
        List<User> userList = new ArrayList<>();
        // Populate your user list here
        return userList;
    }

    public void view_child_3(View view)
    {

        String json = Filter_json_creator("ASHWINI");

        Gson gson = new Gson();

        User yourclass = gson.fromJson(json, User.class);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<User> userList = yourclass.getChildren();

        recyclerView.setAdapter(new UserAdapter(userList));
    }


    public class MenuTree {

        private Menu root;

        public MenuTree() {
            root = new Menu("");
        }

        public void add(String str) {
            Menu current = root;
            StringTokenizer s = new StringTokenizer(str, "/");
            while (s.hasMoreElements()) {
                str = (String) s.nextElement();
                Menu child = current.getChild(str);
                if (child == null) {
                    current.addChild(new Menu(str));
                    child = current.getChild(str);
                }
                current = child;
            }
        }

        public JSONObject toJSON() {
            try {
                return new JSONObject(new ObjectMapper().writeValueAsString(this.root));
            }
            catch (JsonProcessingException e) {

            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    public class Menu {

        private String path;
        private List<Menu> children;

        public Menu(String path) {
            this.path = path;
            children = new ArrayList<>();
        }

        public void addChild(Menu child) {
            children.add(child);
        }

        public List<Menu> getChildren() {
            return children;
        }

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public Menu getChild(String data) {
            for (Menu n : children)
                if (n.path.equals(data)) {return n;}

            return null;
        }


    }



    public ArrayList<String> apidata(){
        String jsondata ="[\n" +
                "{\n" +
                "    \"hierarchy_name\": \"/Tanayarka/CreAdmin Cont\",\n" +
                "    \"user_token_no\": \"CREADMIN-CONT\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/TANAMA-CONT\",\n" +
                "    \"user_name\": \"CreAdmin Cont\"\n" +
                "  },\n" +
                "{\n" +
                "    \"hierarchy_name\": \"/Tanayarka/Cre Res Cont\",\n" +
                "    \"user_token_no\": \"CRERESOR-CONT\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/TANAMA-CONT\",\n" +
                "    \"user_name\": \"Cre Res Cont\"\n" +
                "  },\n" +
                "{\n" +
                "    \"hierarchy_name\": \"/Tanayarka/C MALATHI\",\n" +
                "    \"user_token_no\": \"50001168\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/TANAMA-CONT\",\n" +
                "    \"user_name\": \"C MALATHI\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA\",\n" +
                "    \"user_token_no\": \"S05143\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT\",\n" +
                "    \"user_name\": \"E DHARANIKA\"\n" +
                "  },\n" +
                " \n" +
                "{\n" +
                "    \"hierarchy_name\": \"/Tanayarka\",\n" +
                "    \"user_token_no\": \"TANAMA-CONT\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT\",\n" +
                "    \"user_name\": \"Tanayarka\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/TESTER123\",\n" +
                "    \"user_token_no\": \"ABCD123\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"TESTER123\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/bpm user acceptance testing\",\n" +
                "    \"user_token_no\": \"testbpm-uat1\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"bpm user acceptance testing\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/RMS\",\n" +
                "    \"user_token_no\": \"testing98765-cont\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"RMS\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/migrationtest\",\n" +
                "    \"user_token_no\": \"migration-test\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"migrationtest\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/resource master\",\n" +
                "    \"user_token_no\": \"rm\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"resource master\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/bpm user acceptance testing3\",\n" +
                "    \"user_token_no\": \"testbpm-uat3\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"bpm user acceptance testing3\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/CORDYS UPGRADE\",\n" +
                "    \"user_token_no\": \"CORDYS123\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"CORDYS UPGRADE\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/bpm user acceptance testing4\",\n" +
                "    \"user_token_no\": \"1234567890\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"bpm user acceptance testing4\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/migrationtest1\",\n" +
                "    \"user_token_no\": \"migration-test1\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"migrationtest1\"\n" +
                "  },\n" +
                " {\n" +
                "      \"hierarchy_name\": \"/E DHARANIKA/migrationtest1/ASHWINI\",\n" +
                "      \"user_token_no\": \"205302\",\n" +
                "      \"hierarchy_token\": \"/REVKU-CONT/204374/25007049\",\n" +
                "      \"user_name\": \"ASHWINI\"\n" +
                "    },\n"+
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/testRM\",\n" +
                "    \"user_token_no\": \"testRM12345\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"testRM\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/bpm user acceptance testing2\",\n" +
                "    \"user_token_no\": \"testbpm-uat2\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"bpm user acceptance testing2\"\n" +
                "  }\n" +
                "]";

        ArrayList<String> directory = new ArrayList<>();
        try {
            JSONArray jsonArray = new JSONArray(jsondata);
            int length = jsonArray.length();

            directory.add("/Direct");
            directory.add("/All");
            directory.add("/Kumar Revanth");
            for (int i = 0; i < length; i++) {
                JSONObject jObj = jsonArray.getJSONObject(i);

                String hierarchy_name = jObj.optString("hierarchy_name");
                directory.add("/Kumar Revanth"+hierarchy_name);

                String user_name = jObj.optString("user_name");
                String user_token_no = jObj.optString("user_token_no");
                User_userid.put( user_name , user_token_no );

            }
            return directory ;
        }catch (JSONException e) {
            e.printStackTrace();
        }
        return directory ;

    }



    public ArrayList<String> filter( String data){
        String jsondata ="[\n" +
                "{\n" +
                "    \"hierarchy_name\": \"/Tanayarka/CreAdmin Cont\",\n" +
                "    \"user_token_no\": \"CREADMIN-CONT\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/TANAMA-CONT\",\n" +
                "    \"user_name\": \"CreAdmin Cont\"\n" +
                "  },\n" +
                "{\n" +
                "    \"hierarchy_name\": \"/Tanayarka/Cre Res Cont\",\n" +
                "    \"user_token_no\": \"CRERESOR-CONT\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/TANAMA-CONT\",\n" +
                "    \"user_name\": \"Cre Res Cont\"\n" +
                "  },\n" +
                "{\n" +
                "    \"hierarchy_name\": \"/Tanayarka/C MALATHI\",\n" +
                "    \"user_token_no\": \"50001168\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/TANAMA-CONT\",\n" +
                "    \"user_name\": \"C MALATHI\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA\",\n" +
                "    \"user_token_no\": \"S05143\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT\",\n" +
                "    \"user_name\": \"E DHARANIKA\"\n" +
                "  },\n" +
                " \n" +
                "{\n" +
                "    \"hierarchy_name\": \"/Tanayarka\",\n" +
                "    \"user_token_no\": \"TANAMA-CONT\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT\",\n" +
                "    \"user_name\": \"Tanayarka\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/TESTER123\",\n" +
                "    \"user_token_no\": \"ABCD123\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"TESTER123\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/bpm user acceptance testing\",\n" +
                "    \"user_token_no\": \"testbpm-uat1\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"bpm user acceptance testing\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/RMS\",\n" +
                "    \"user_token_no\": \"testing98765-cont\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"RMS\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/migrationtest\",\n" +
                "    \"user_token_no\": \"migration-test\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"migrationtest\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/resource master\",\n" +
                "    \"user_token_no\": \"rm\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"resource master\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/bpm user acceptance testing3\",\n" +
                "    \"user_token_no\": \"testbpm-uat3\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"bpm user acceptance testing3\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/CORDYS UPGRADE\",\n" +
                "    \"user_token_no\": \"CORDYS123\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"CORDYS UPGRADE\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/bpm user acceptance testing4\",\n" +
                "    \"user_token_no\": \"1234567890\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"bpm user acceptance testing4\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/migrationtest1\",\n" +
                "    \"user_token_no\": \"migration-test1\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"migrationtest1\"\n" +
                "  },\n" +
                " {\n" +
                "      \"hierarchy_name\": \"/E DHARANIKA/migrationtest1/ASHWINI\",\n" +
                "      \"user_token_no\": \"205302\",\n" +
                "      \"hierarchy_token\": \"/REVKU-CONT/204374/25007049\",\n" +
                "      \"user_name\": \"ASHWINI\"\n" +
                "    },\n"+
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/testRM\",\n" +
                "    \"user_token_no\": \"testRM12345\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"testRM\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/bpm user acceptance testing2\",\n" +
                "    \"user_token_no\": \"testbpm-uat2\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"bpm user acceptance testing2\"\n" +
                "  }\n" +
                "]";

        ArrayList<String> directory = new ArrayList<>();
        try {
            JSONArray jsonArray = new JSONArray(jsondata);
            int length = jsonArray.length();

            directory.add("/Direct");
            directory.add("/All");
            directory.add("/Kumar Revanth");
            for (int i = 0; i < length; i++) {

                    JSONObject jObj = jsonArray.getJSONObject(i);

                    String hierarchy_name = jObj.optString("hierarchy_name");
                if (hierarchy_name.contains( data )) {
                    directory.add("/Kumar Revanth" + hierarchy_name);
                }
                    String user_name = jObj.optString("user_name");
                    String user_token_no = jObj.optString("user_token_no");
                    User_userid.put(user_name, user_token_no);

            }
            return directory ;
        }catch (JSONException e) {
            e.printStackTrace();
        }
        return directory ;

    }
}