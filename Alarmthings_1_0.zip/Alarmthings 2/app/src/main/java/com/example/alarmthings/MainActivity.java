package com.example.alarmthings;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.alarmthings.Animate.AnimatActivity;

import java.text.DateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity  implements
        TimePickerDialog.OnTimeSetListener ,
            com.wdullaer.materialdatetimepicker.date.DatePickerDialog.OnDateSetListener{

    private TextView mTextView , alarm1_tv ,alarm2_tv ,alarm3_tv ,alarm4_tv;

    int timer_id=0;

    private static MainActivity instant ;

    int sel_date , sel_year , sel_month ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        checkOverlayPermission();
//        window_popup();

        instant =this ;

        mTextView = findViewById(R.id.textView);

        alarm1_tv  = findViewById(R.id.alarm1_tv);
        alarm2_tv  = findViewById(R.id.alarm2_tv);
        alarm3_tv  = findViewById(R.id.alarm3_tv);
        alarm4_tv  = findViewById(R.id.alarm4_tv);


        Button buttonTimePicker = findViewById(R.id.button_timepicker);
        Button buttonCancelAlarm = findViewById(R.id.button_cancel);


        Button btn_1 = findViewById(R.id.btn_1);
        Button btn_2 = findViewById(R.id.btn_2);
        Button btn_3 = findViewById(R.id.btn_3);
        Button btn_4 = findViewById(R.id.btn_4);


        Button can_btn_1 = findViewById(R.id.can_btn_1);
        Button can_btn_2 = findViewById(R.id.can_btn_2);
        Button can_btn_3 = findViewById(R.id.can_btn_3);
        Button can_btn_4 = findViewById(R.id.can_btn_4);


        buttonTimePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment timePicker = new TimePickerFragment();
                timePicker.show(getSupportFragmentManager(), "time picker");
            }
        });

        buttonCancelAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelAlarm( 0 );
            }
        });


        btn_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timepicker(1);
            }
        });

        btn_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timepicker(2);
            }
        });

        btn_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timepicker(3);
            }
        });

        btn_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timepicker(4 );
            }
        });


        can_btn_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelAlarm( 1 );
            }
        });

        can_btn_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelAlarm( 2 );
            }
        });

        can_btn_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelAlarm( 3 );
            }
        });

        can_btn_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                cancelAlarm( 4 );
        startActivity(new Intent(MainActivity.this , AnimatActivity.class));
            }
        });


    }

    public void checkOverlayPermission(){

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                // send user to the device settings
                Intent myIntent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                startActivity(myIntent);
            }
        }
    }


    public void timepicker( int time_id ){
        DialogFragment timePicker = new TimePickerFragment();
        timePicker.show(getSupportFragmentManager(), "time picker");
        timer_id = time_id ;
    }



    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.YEAR, sel_year );
        c.set(Calendar.MONTH, sel_month );
        c.set(Calendar.DAY_OF_MONTH, sel_date );
        c.set(Calendar.HOUR_OF_DAY, hourOfDay);
        c.set(Calendar.MINUTE, minute);
        c.set(Calendar.SECOND, 0);
        updateTimeText(c);
        startAlarm(c);
    }
    private void updateTimeText(Calendar c) {
        String timeText = "";
        timeText += DateFormat.getTimeInstance(DateFormat.SHORT).format(c.getTime());
        mTextView.setText(timeText);

        if ( timer_id ==1){
            alarm1_tv.setText(timeText);
        }
        else if ( timer_id ==2){
            alarm2_tv.setText(timeText);
        }
        else if ( timer_id ==3){
            alarm3_tv.setText(timeText);
        }
        else if ( timer_id ==4){
            alarm4_tv.setText(timeText);
        }

    }
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void startAlarm(Calendar c)
    {
//        final int id = (int) System.currentTimeMillis();        // main thing of multi alarm set

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, AlertReceiver.class);
        Toast.makeText(this, "Alarm created : "+timer_id, Toast.LENGTH_SHORT).show();


        if (c.before(Calendar.getInstance())) {
            c.add(Calendar.DATE, 1);
        }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            PendingIntent pendingIntent = PendingIntent.getBroadcast(this, timer_id, intent, PendingIntent.FLAG_IMMUTABLE);
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pendingIntent);
        }
        else {
            PendingIntent pendingIntent = PendingIntent.getBroadcast(this, timer_id , intent, 0);
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pendingIntent);
        }



    }

    private void cancelAlarm( int time ) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, AlertReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, time, intent, 0);
        alarmManager.cancel(pendingIntent);
        mTextView.setText("Alarm canceled");
        Toast.makeText(this, "Alarm canceled : "+time, Toast.LENGTH_SHORT).show();

    }


    public static MainActivity getInstace(){
        return instant;
    }

    public void updateTheTextView(final String data) {
        MainActivity.this.runOnUiThread(new Runnable() {
            public void run() {

                final MediaPlayer mediaPlayer = MediaPlayer.create(MainActivity.this, Settings.System.DEFAULT_RINGTONE_URI);
                mediaPlayer.start();

                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Alarm")
                        .setMessage("Alarm completed ...")
                        .setCancelable(false)
                        .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                mediaPlayer.stop();
                                dialog.cancel();

                            }
                        }).show();

                Toast.makeText(MainActivity.this, "send by broadcast", Toast.LENGTH_SHORT).show();


            }
        });
    }



    public void clickpicker(View view) {
        datepicker();
    }

    private void datepicker( ) {
        final Calendar c = Calendar.getInstance();
        int mYear = c.get(Calendar.YEAR);
        int mMonth = c.get(Calendar.MONTH);
        int mDay = c.get(Calendar.DAY_OF_MONTH);
//
//        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
//                new DatePickerDialog.OnDateSetListener() {
//
//                    @Override
//                    public void onDateSet(DatePicker view, int year,
//                                          int monthOfYear, int dayOfMonth) {
//                        String date = "" + dayOfMonth;
//                        String month = "" + (monthOfYear + 1);
//                        Toast.makeText(MainActivity.this, date+" + "+month, Toast.LENGTH_SHORT).show();
//                    }
//                }, mYear, mMonth, mDay);
//
//        datePickerDialog.getDatePicker().setMinDate(c.getTimeInMillis());
//
//        datePickerDialog.show();




        try {
            Calendar mCalendar2 = Calendar.getInstance();

            com.wdullaer.materialdatetimepicker.date.DatePickerDialog dpd
                    = com.wdullaer.materialdatetimepicker.date.DatePickerDialog.newInstance(
                    MainActivity.this,
                    mCalendar2.get(Calendar.DAY_OF_MONTH),
                    mCalendar2.get(Calendar.MONTH),
                    mCalendar2.get(Calendar.YEAR)
            );


            mCalendar2.set( 2023 , 7 , 29 ) ;
            dpd.setMinDate(mCalendar2);

//            Calendar c2 = Calendar.getInstance();
//            c2.set(Calendar.YEAR, 2023 );
//            c2.set(Calendar.MONTH, Calendar.MARCH);        //---not working
//            c2.set(Calendar.DAY_OF_MONTH, 28);
////            c2.set(Calendar.HOUR_OF_DAY, hourOfDay);
////            c2.set(Calendar.MINUTE, minute);
////            c2.set(Calendar.SECOND, 0);
//            dpd.setMaxDate(c2);

//            mCalendar2.add(Calendar.DAY_OF_WEEK,2);   //---working fine
//            dpd.setMaxDate(mCalendar2);

            dpd.show(this.getFragmentManager(), "Select Later Date");
        }
        catch (Exception e){

        }
    }

    @Override
    public void onDateSet(com.wdullaer.materialdatetimepicker.date.DatePickerDialog view, int year, int monthOfYear, int dayOfMonth) {
        sel_date = dayOfMonth ;
        sel_year = year ;
        sel_month = monthOfYear ;
    }


    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
        super.onBackPressed();

    }

    @Override
    protected void onDestroy() {
        moveTaskToBack(true);
        super.onDestroy();
    }
}