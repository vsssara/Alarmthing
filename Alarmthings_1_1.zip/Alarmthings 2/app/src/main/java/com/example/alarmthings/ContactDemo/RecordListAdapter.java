package com.example.alarmthings.ContactDemo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.alarmthings.R;

import java.util.ArrayList;

public class RecordListAdapter extends BaseAdapter {
    private Context context;
    private int layout;
    private ArrayList<Model> recordList;

    public RecordListAdapter(Context context, int layout, ArrayList<Model> recordList) {
        this.context = context;
        this.layout = layout;
        this.recordList = recordList;
    }

    @Override
    public int getCount() {
        return recordList.size();
    }

    @Override
    public Object getItem(int i) {
        return recordList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    private class ViewHolder{
        ImageView imageView;
        TextView txtName,txtAge,txtPhone,id_item;

    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        View row = view;
        ViewHolder holder = new ViewHolder();

        if (row==null)
        {
            LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(layout, null);
            holder.txtName = row.findViewById(R.id.UserName);
            holder.txtAge = row.findViewById(R.id.pass);
            holder.txtPhone = row.findViewById(R.id.Phone_no);
            holder.imageView = row.findViewById(R.id.image);
            holder.id_item = row.findViewById(R.id.id_item);
            row.setTag(holder);

//             SwipeLayout swipeLayout;
//            swipeLayout = (SwipeLayout)row.findViewById(R.id.swipe_layout);

        //    swipeLayout.setShowMode(SwipeLayout.ShowMode.LayDown);

        }
        else {
            holder = (ViewHolder)row.getTag();
        }

        Model model = recordList.get(i);

        holder.txtName.setText(model.getName());
        holder.txtAge.setText(model.getAge());
        holder.txtPhone.setText(model.getPhone());

        int e=model.getId();
        String numberAsString = new Integer(e).toString();
        holder.id_item.setText(numberAsString);

    if( model.getImage()!=null )
     {
    byte[] recordImage = model.getImage();
    Bitmap bitmap = BitmapFactory.decodeByteArray(recordImage, 0, recordImage.length);
    holder.imageView.setImageBitmap(bitmap);
     }

        return row;
    }


}

