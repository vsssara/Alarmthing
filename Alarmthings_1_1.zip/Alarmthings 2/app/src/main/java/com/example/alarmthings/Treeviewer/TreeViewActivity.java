package com.example.alarmthings.Treeviewer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

import com.example.alarmthings.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

public class TreeViewActivity extends AppCompatActivity {

    private TreeViewAdapter treeViewAdapter;

    private static final String TAG = "FileTreeFragment";

    HashMap<String , String > loaddata = new HashMap<String, String>();
    HashMap<String , String > loaddata_id = new HashMap<String, String>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tree_view);

        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setNestedScrollingEnabled(false);

        TreeViewHolderFactory factory = (v, layout) -> new CustomViewHolder(v);

        treeViewAdapter = new TreeViewAdapter(factory);
        recyclerView.setAdapter(treeViewAdapter);




        String jsondata ="[\n" +
                "{\n" +
                "    \"hierarchy_name\": \"/Tanayarka/CreAdmin Cont\",\n" +
                "    \"user_token_no\": \"CREADMIN-CONT\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/TANAMA-CONT\",\n" +
                "    \"user_name\": \"CreAdmin Cont\"\n" +
                "  },\n" +
                "{\n" +
                "    \"hierarchy_name\": \"/Tanayarka/Cre Res Cont\",\n" +
                "    \"user_token_no\": \"CRERESOR-CONT\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/TANAMA-CONT\",\n" +
                "    \"user_name\": \"Cre Res Cont\"\n" +
                "  },\n" +
                "{\n" +
                "    \"hierarchy_name\": \"/Tanayarka/C MALATHI\",\n" +
                "    \"user_token_no\": \"50001168\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/TANAMA-CONT\",\n" +
                "    \"user_name\": \"C MALATHI\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA\",\n" +
                "    \"user_token_no\": \"S05143\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT\",\n" +
                "    \"user_name\": \"E DHARANIKA\"\n" +
                "  },\n" +
                " \n" +
                "{\n" +
                "    \"hierarchy_name\": \"/Tanayarka\",\n" +
                "    \"user_token_no\": \"TANAMA-CONT\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT\",\n" +
                "    \"user_name\": \"Tanayarka\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/TESTER123\",\n" +
                "    \"user_token_no\": \"ABCD123\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"TESTER123\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/bpm user acceptance testing\",\n" +
                "    \"user_token_no\": \"testbpm-uat1\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"bpm user acceptance testing\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/RMS\",\n" +
                "    \"user_token_no\": \"testing98765-cont\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"RMS\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/migrationtest\",\n" +
                "    \"user_token_no\": \"migration-test\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"migrationtest\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/resource master\",\n" +
                "    \"user_token_no\": \"rm\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"resource master\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/bpm user acceptance testing3\",\n" +
                "    \"user_token_no\": \"testbpm-uat3\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"bpm user acceptance testing3\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/CORDYS UPGRADE\",\n" +
                "    \"user_token_no\": \"CORDYS123\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"CORDYS UPGRADE\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/bpm user acceptance testing4\",\n" +
                "    \"user_token_no\": \"1234567890\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"bpm user acceptance testing4\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/migrationtest1\",\n" +
                "    \"user_token_no\": \"migration-test1\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"migrationtest1\"\n" +
                "  },\n" +
                " {\n" +
                "      \"hierarchy_name\": \"/E DHARANIKA/migrationtest1/ASHWINI\",\n" +
                "      \"user_token_no\": \"205302\",\n" +
                "      \"hierarchy_token\": \"/REVKU-CONT/204374/25007049\",\n" +
                "      \"user_name\": \"ASHWINI\"\n" +
                "    },\n"+
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/testRM\",\n" +
                "    \"user_token_no\": \"testRM12345\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"testRM\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"hierarchy_name\": \"/E DHARANIKA/bpm user acceptance testing2\",\n" +
                "    \"user_token_no\": \"testbpm-uat2\",\n" +
                "    \"hierarchy_token\": \"/REVKU-CONT/S05143\",\n" +
                "    \"user_name\": \"bpm user acceptance testing2\"\n" +
                "  }\n" +
                "]";

//                "[\n" +
//                        "  {\n" +
//                        "    \"hierarchy_name\": \"/Tanayarka/CreAdmin Cont\",\n" +
//                        "    \"hierarchy_token\": \"/REVKU-CONT/TANAMA-CONT\",\n" +
//                        "    \"user_token_no\": \"CREADMIN-CONT\",\n" +
//                        "    \"user_name\": \"CreAdmin Cont\"\n" +
//                        "  },\n" +
//                        "  {\n" +
//                        "    \"hierarchy_name\": \"/Tanayarka/Cre Res Cont\",\n" +
//                        "    \"hierarchy_token\": \"/REVKU-CONT/TANAMA-CONT\",\n" +
//                        "    \"user_token_no\": \"CRERESOR-CONT\",\n" +
//                        "    \"user_name\": \"Cre Res Cont\"\n" +
//                        "  },\n" +
//                        "  {\n" +
//                        "    \"hierarchy_name\": \"/Tanayarka/C MALATHI\",\n" +
//                        "    \"hierarchy_token\": \"/REVKU-CONT/TANAMA-CONT\",\n" +
//                        "    \"user_token_no\": \"50001168\",\n" +
//                        "    \"user_name\": \"C MALATHI\"\n" +
//                        "  },\n" +
//                        "  {\n" +
//                        "    \"hierarchy_name\": \"/E DHARANIKA\",\n" +
//                        "    \"hierarchy_token\": \"/REVKU-CONT\",\n" +
//                        "    \"user_name\": \"E DHARANIKA\",\n" +
//                        "    \"user_token_no\": \"S05143\"\n" +
//
//                        "  },\n" +
//                        "  {\n" +
//                        "    \"hierarchy_name\": \"/Tanayarka\",\n" +
//                        "    \"hierarchy_token\": \"/REVKU-CONT\",\n" +
//                        "    \"user_token_no\": \"TANAMA-CONT\",\n" +
//                        "    \"user_name\": \"Tanayarka\"\n" +
//                        "  }\n" +
//                        "]";


//        JSONObject jsonObject = new JSONObject(json);





        try {
            JSONArray jsonArray = new JSONArray(jsondata);
            int length = jsonArray.length();

            List<TreeNode> __fileRoots = new ArrayList<>();
            TreeNode Direct = new TreeNode("Direct","Direct" , R.layout.list_item_file);
            TreeNode All = new TreeNode("All","All" , R.layout.list_item_file);

            TreeNode USER = new TreeNode("REVANTH KUMAR","REVKU-CONT" , R.layout.list_item_file);

            ArrayList<String> temp_hyris_data = new ArrayList<>();

            for(int i=0; i<length; i++) {
                JSONObject jObj = jsonArray.getJSONObject(i);

                String hierarchy_name = jObj.optString("hierarchy_name");
                Log.e(TAG, "forloop " + hierarchy_name );
                String replacedString = hierarchy_name.replace("/", "_");
                Log.e(TAG, "forbacksplas " + replacedString );
                String[] str_replace = replacedString.split("_");

                String user_token_no = jObj.optString("user_token_no");
                String user_name = jObj.optString("user_name");
                loaddata_id.put( user_name , user_token_no );

                if (str_replace.length==2){
//                    USER.addChild(new TreeNode(str_replace[1],"id1" , R.layout.list_item_file));
                    if (loaddata.containsKey("REVKU-CONT_"+str_replace[1]))
                    {
//                        String temp = loaddata.get("REVKU-CONT_"+str_replace[1]);
//                        loaddata.put( "REVKU-CONT_"+str_replace[1] , temp+"_"+str_replace[1]);
                        temp_hyris_data.add("REVKU-CONT_" + str_replace[1]);
                    }
                    else {
                        loaddata.put("REVKU-CONT_" + str_replace[1], " ");

                        temp_hyris_data.add("REVKU-CONT_" + str_replace[1]);
                    }
                }
                else if (str_replace.length==3){
//                    TreeNode cDirectory = new TreeNode(str_replace[1], "id1" ,R.layout.list_item_file);
//                    cDirectory.addChild(new TreeNode(str_replace[2],"id1" , R.layout.list_item_file));
//                    USER.addChild(cDirectory);
                    if (loaddata.containsKey("REVKU-CONT_"+str_replace[1]))
                    {
                        String temp = loaddata.get("REVKU-CONT_"+str_replace[1]);
                        loaddata.put( "REVKU-CONT_"+str_replace[1] , temp+"_"+str_replace[2]);
                    }
                    else {
                        loaddata.put( "REVKU-CONT_"+str_replace[1] ,str_replace[2]);
                    }

                }
                else if (str_replace.length==4){
                    if (loaddata.containsKey("REVKU-CONT_"+str_replace[1]))
                    {
                        String temp = loaddata.get("REVKU-CONT_"+str_replace[1]);
                        loaddata.put( "REVKU-CONT_"+str_replace[1] , temp+"_"+str_replace[2]+"#"+str_replace[3]);
                    }
                    else {
                        loaddata.put( "REVKU-CONT_"+str_replace[1] ,str_replace[2]+"#"+str_replace[3]);
                    }
                }

                String hierarchy_token = jObj.optString("hierarchy_token");
//                String replacedString = hierarchy_token.replace("/", "_");
//                Log.e(TAG, "forbacksplas " + replacedString );
//                String separator = ".\";
//                String[] str_replace = hierarchy_token.replaceAll(Pattern.quote(separator), "\\\\").split("\\\\");
//
//                if (str_replace.length >= 1){
//                    Log.e(TAG, "forbacksplas " + str_replace[0] );
//                }

            }

            for (int i=0 ; i<loaddata.size();i++)
            {
              String data =  loaddata.get(temp_hyris_data.get(i));
                String[] child_1 = temp_hyris_data.get(i).split("_");
                TreeNode cDirectory = new TreeNode( child_1[1], "id1" ,R.layout.list_item_file);

                String[] str_replace = data.split("_");
                String[] str_replace2 = str_replace[0].split("#");
                TreeNode child22 = new TreeNode( str_replace2[0], "id1" ,R.layout.list_item_file);
                for (int j=0 ; j<str_replace.length ;j++){
                    if (str_replace[j].contains("#")){
                        String[] child_2 = str_replace[j].split("#");

                        child22.addChild(new TreeNode( child_2[1], "id1", R.layout.list_item_file));
                        USER.addChild(child22);
                    }
                    else {
                        if (str_replace[j].equals(" ")) {

                        } else {
                            cDirectory.addChild(new TreeNode(str_replace[j], "id1", R.layout.list_item_file));
                        }
                    }
                    if (str_replace.length == j){

                    }
                }
                USER.addChild(cDirectory);
            }


            __fileRoots.add(Direct);
            __fileRoots.add(All);
            __fileRoots.add(USER);
            treeViewAdapter.updateTreeNodes(__fileRoots);

            } catch (JSONException e) {
            e.printStackTrace();
        }

//        TreeNode javaDirectory = new TreeNode("Java", "id1" , R.layout.list_item_file);
//        javaDirectory.addChild(new TreeNode("FileJava1.java","id2" , R.layout.list_item_file));
//        javaDirectory.addChild(new TreeNode("FileJava2.java","id3" , R.layout.list_item_file));
//        javaDirectory.addChild(new TreeNode("FileJava3.java","id4" , R.layout.list_item_file));
//
//        TreeNode gradleDirectory = new TreeNode("Gradle", "id5" ,R.layout.list_item_file);
//        gradleDirectory.addChild(new TreeNode("FileGradle1.gradle","id6" , R.layout.list_item_file));
//        gradleDirectory.addChild(new TreeNode("FileGradle2.gradle", "id7" ,R.layout.list_item_file));
//        gradleDirectory.addChild(new TreeNode("FileGradle3.gradle", "id8" ,R.layout.list_item_file));
//
//        javaDirectory.addChild(gradleDirectory);
//
//        TreeNode lowLevelRoot = new TreeNode("LowLevel","id9" , R.layout.list_item_file);
//
//        TreeNode cDirectory = new TreeNode("C", "id1" ,R.layout.list_item_file);
//        cDirectory.addChild(new TreeNode("FileC1.c","id1" , R.layout.list_item_file));
//        cDirectory.addChild(new TreeNode("FileC2.c", "id1" ,R.layout.list_item_file));
//        cDirectory.addChild(new TreeNode("FileC3.c", "id1" ,R.layout.list_item_file));
//
//        TreeNode cppDirectory = new TreeNode("Cpp","id1" , R.layout.list_item_file);
//        cppDirectory.addChild(new TreeNode("FileCpp1.cpp","id1" , R.layout.list_item_file));
//        cppDirectory.addChild(new TreeNode("FileCpp2.cpp","id1" , R.layout.list_item_file));
//        cppDirectory.addChild(new TreeNode("FileCpp3.cpp","id1" , R.layout.list_item_file));
//
//        TreeNode goDirectory = new TreeNode("Go","id1" , R.layout.list_item_file);
//        goDirectory.addChild(new TreeNode("FileGo1.go","id1" , R.layout.list_item_file));
//        goDirectory.addChild(new TreeNode("FileGo2.go","id1" , R.layout.list_item_file));
//        goDirectory.addChild(new TreeNode("FileGo3.go","id1" , R.layout.list_item_file));
//
//        lowLevelRoot.addChild(cDirectory);
//        lowLevelRoot.addChild(cppDirectory);
//        lowLevelRoot.addChild(goDirectory);
//
//        TreeNode cSharpDirectory = new TreeNode("C#","id1" , R.layout.list_item_file);
//        cSharpDirectory.addChild(new TreeNode("FileCs1.cs","id1" , R.layout.list_item_file));
//        cSharpDirectory.addChild(new TreeNode("FileCs2.cs","id1" , R.layout.list_item_file));
//        cSharpDirectory.addChild(new TreeNode("FileCs3.cs","id1" , R.layout.list_item_file));
//
//
//        TreeNode gitFolder = new TreeNode(".git","id1" , R.layout.list_item_file);
//
//        List<TreeNode> fileRoots = new ArrayList<>();
//        fileRoots.add(javaDirectory);
//        fileRoots.add(lowLevelRoot);
//        fileRoots.add(cSharpDirectory);
//        fileRoots.add(gitFolder);
//
//        treeViewAdapter.updateTreeNodes(fileRoots);

        treeViewAdapter.setTreeNodeClickListener((treeNode, nodeView) -> {
            Log.d(TAG, "Click on TreeNode with value " + treeNode.getValue().toString());
            Log.d(TAG, "Click on TreeNode with value " + treeNode.getValueid().toString());


//
            if(!treeNode.getValue().toString().equals("REVANTH KUMAR")){
                Log.e("selectedID" , loaddata_id.get(treeNode.getValue().toString()));
            }
        });

        treeViewAdapter.setTreeNodeLongClickListener((treeNode, nodeView) -> {
            Log.d(TAG, "LongClick on TreeNode with value " + treeNode.getValue().toString());
            Log.d(TAG, "Click on TreeNode with value " + treeNode.getValueid().toString());
            return true;
        });


    }
}