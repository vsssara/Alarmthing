package com.example.alarmthings.ContactDemo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.alarmthings.R;

public class DashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash);

    }

    public void ADD_clk(View view)
    {
        startActivity(new Intent(DashActivity.this, MainActivity.class));
    }

    public void View_clk(View view)
    {
        startActivity(new Intent(DashActivity.this, DetailsActivity.class));
    }

    public void Edit_clk(View view)
    {

    }
}
