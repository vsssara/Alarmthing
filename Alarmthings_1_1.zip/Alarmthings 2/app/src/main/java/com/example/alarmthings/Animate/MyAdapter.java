package com.example.alarmthings.Animate;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.example.alarmthings.R;

import java.util.ArrayList;

class MyAdapter extends ArrayAdapter<String> {

    Context context;
    ArrayList<String> rImgs;
    ArrayList<String> Facility_arr;
    ArrayList<String> user_id_arr;


    MyAdapter (Context c,ArrayList<String> imgs ,ArrayList<String> Facility ,ArrayList<String> user_id_arr  ) {
        super(c, R.layout.item, R.id.helloText, user_id_arr );
        this.context = c;
        this.rImgs = imgs;
        this.Facility_arr = Facility;
        this.user_id_arr = user_id_arr;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row = layoutInflater.inflate(R.layout.item, parent, false);

        ImageView images = row.findViewById(R.id.image_prof);
        TextView HouseOwnerName = row.findViewById(R.id.helloText);



//
        // now set our resources on views
//            images.setImageResource(rImgs[position]);
//            myTitle.setText(rTitle[position]);
//            myDescription.setText(rDescription[position]);

//        images.setImageResource(rImgs.get(position));

        HouseOwnerName.setText(user_id_arr.get(position));
        Glide.with(context).load(rImgs.get(position)).into(images);



//        Facility.setText( Facility_arr.get(position));
//        Rent.setText(Rent_arr.get(position));
//        userid.setText(user_id_arr.get(position));

        return row;
    }


}
